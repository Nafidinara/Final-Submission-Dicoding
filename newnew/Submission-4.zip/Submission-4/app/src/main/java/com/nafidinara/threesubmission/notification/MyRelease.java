package com.nafidinara.threesubmission.notification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.nafidinara.threesubmission.R;
import com.nafidinara.threesubmission.activity.MainActivity;
import com.nafidinara.threesubmission.connection.ApiService;
import com.nafidinara.threesubmission.connection.RetroConfig;
import com.nafidinara.threesubmission.model.Movie;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyRelease extends BroadcastReceiver {
    @Override
    public void onReceive(final Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        String api = RetroConfig.getApiKey();
//        throw new UnsupportedOperationException("Not yet implemented");
        ApiService service = RetroConfig.getRetrofit().create(ApiService.class);
        Call<Movie> movieCall = service.getMovie(api);
        movieCall.enqueue(new Callback<Movie>() {
            @Override
            public void onResponse(Call<Movie> call, Response<Movie> response) {
                assert response.body() != null;
//             Log.d("test", String.valueOf(response.body().getResults().get(0).getTitle()));
                for (int i = 0; i < response.body().getResults().size();i++){
                    Log.d("test",response.body().getResults().get(i).getTitle());
                    Intent release = new Intent(context, MainActivity.class);

                    PendingIntent pendingIntent = PendingIntent.getBroadcast(context,111,release,PendingIntent.FLAG_UPDATE_CURRENT);

                    NotificationManager daily_notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                    NotificationCompat.Builder daily_builder = new NotificationCompat.Builder(context,response.body().getResults().get(i).getTitle())
                            .setContentIntent(pendingIntent)
                            .setSmallIcon(R.mipmap.ic_launcher)
                            .setLargeIcon(BitmapFactory.decodeResource(context.getResources(),R.mipmap.ic_launcher))
                            .setContentTitle(context.getResources().getString(R.string.app_name))
                            .setContentText(response.body().getResults().get(i).getTitle())
                            .setAutoCancel(true);
                    Notification notification = daily_builder.build();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                        NotificationChannel channel = new NotificationChannel(response.body().getResults().get(i).getTitle(), response.body().getResults().get(i).getTitle(), NotificationManager.IMPORTANCE_DEFAULT);
                        daily_builder.setChannelId(response.body().getResults().get(i).getTitle());

                        if (daily_notificationManager != null) {
                            daily_notificationManager.createNotificationChannel(channel);
                        }
                    }
                    if (daily_notificationManager !=null){
                        daily_notificationManager.notify(i,notification);
                    }
                }


            }

            @Override
            public void onFailure(Call<Movie> call, Throwable t) {

            }
        });
    }
}
