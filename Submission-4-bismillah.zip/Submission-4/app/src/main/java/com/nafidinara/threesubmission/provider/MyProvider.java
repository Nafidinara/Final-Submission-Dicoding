package com.nafidinara.threesubmission.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;

import com.nafidinara.threesubmission.db.MovieHelper;
import com.nafidinara.threesubmission.db.TvHelper;

import java.net.URI;
import java.util.Objects;

import static com.nafidinara.threesubmission.db.MovieDbContract.AUTH;
import static com.nafidinara.threesubmission.db.MovieDbContract.MovieColumns.TABLE_MOVIE_NAME;
import static com.nafidinara.threesubmission.db.TvDbContract.TvColumns.TABLE_TV_NAME;

public class MyProvider extends ContentProvider {
    MovieHelper movieHelper;
    TvHelper tvHelper;
    static final int MOVIE=10;
    static final int MOVIE_ID=11;
    static final int TV=12;
    static final int TV_ID=13;
    private static final UriMatcher URI_MATCHER = new UriMatcher(UriMatcher.NO_MATCH);

    public MyProvider() {
    }
    static {
        URI_MATCHER.addURI(AUTH,TABLE_MOVIE_NAME,MOVIE);
        URI_MATCHER.addURI(AUTH,TABLE_MOVIE_NAME + "/#",MOVIE_ID);
        URI_MATCHER.addURI(AUTH,TABLE_TV_NAME,TV);
        URI_MATCHER.addURI(AUTH,TABLE_TV_NAME + "/#",TV_ID);

    }
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

        // Implement this to handle requests to delete one or more rows.
//        throw new UnsupportedOperationException("Not yet implemented");
        int deleted;
        switch (URI_MATCHER.match(uri)){
            case MOVIE_ID:
                deleted = movieHelper.movieDeleteProvider(uri.getLastPathSegment());
                break;
            case TV_ID:
                deleted = tvHelper.tvDeleteProvider(uri.getLastPathSegment());
                break;
                default:
                    deleted = 0;
                    break;

        }
        if (deleted > 0){
            Objects.requireNonNull(getContext()).getContentResolver().notifyChange(uri,null);

        }
        return deleted;
    }

    @Override
    public String getType(Uri uri) {
        // TODO: Implement this to handle requests for the MIME type of the data
        // at the given URI.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO: Implement this to handle requests to insert a new row.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public boolean onCreate() {
        // TODO: Implement this to initialize your content provider on startup.
        tvHelper = TvHelper.getInst(getContext());
        tvHelper.open();
        movieHelper = MovieHelper.getInst(getContext());
        movieHelper.open();
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        // TODO: Implement this to handle query requests from clients.
        Cursor cursor;
        switch (URI_MATCHER.match(uri)){
            case MOVIE:
                cursor = movieHelper.cursorMovieGet();
                break;
            case TV:
                cursor = tvHelper.cursorTvGet();
                break;
                default:
                    cursor=null;
                    break;
        }
        if (cursor != null){
            cursor.setNotificationUri(Objects.requireNonNull(getContext()).getContentResolver(),uri);
        }
        return cursor;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        // TODO: Implement this to handle requests to update one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
